<!doctype html>
<html>
<head>

<title>Newsletter</title>

<style type="text/css">

	.success {
	width:500px;
	height:200px;
	background-color:#ddd;
	margin:0px auto;
	padding:15px;
	font-size:21px;
	font-weight:bold;
	text-align:center;
	}
	
	a {
	text-decoration:none;
	color:#4E96F4;
	}
	
</style>
</head>

<body>
<div class="success">
<?php echo "Your Newsletter was successfully sent "; ?>
<br />
<a href="index.php">Home page</a>
</div>
</body>

</html>